import 'package:flutter/material.dart';

class ProductStyle extends StatefulWidget {
  final List? productStyles;
  final Function(String)? onSelectedStyle;
  ProductStyle({this.productStyles, this.onSelectedStyle});

  @override
  _ProductStyleState createState() => _ProductStyleState();
}

class _ProductStyleState extends State<ProductStyle> {

  int _selectedStyle = 0;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 20.0,
      ),
      child: Wrap(
        children: [
          for (var i = 0; i < widget.productStyles!.length; i++)
            GestureDetector(
              onTap: () {
                widget.onSelectedStyle!("${widget.productStyles![i]}");
                setState(() {
                  _selectedStyle = i;
                });
              },
              child: Container(
                width: 80.0,
                height: 50.0,
                decoration: BoxDecoration(
                  color: _selectedStyle == i ? Theme.of(context).accentColor : Color(0xFFDCDCDC),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                alignment: Alignment.center,
                margin: EdgeInsets.symmetric(
                  horizontal: 6.0,
                  vertical: 5.0,
                ),
                child: Text(
                  "${widget.productStyles![i]}",
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: _selectedStyle == i ? Colors.white : Colors.black,
                  fontSize: 16.0,
                  ),
                ),
              ),
            )
        ],
      ),
    );
  }
}
